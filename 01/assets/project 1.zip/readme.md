# Project 1 - HTML5 and CSS 

By Sujal

## [Link for Project 1](https://trending2025.netlify.app/) 

![project 1 completed](./thumbnail.png)

## What I learned ? How was my experience while making this project?

- This project was the first project provided by full stack web developer bootcamp and it was a great experience while creating this web page.
- I learned how to use HTML and CSS to create a attractive website.
- I learned about various css properties and tags.
- I learned about z index to stack elements on top of each other.
- I learned about the properties of positions of elements in the HTML and CSS.

## This project took almost 6:40 hours to complete.